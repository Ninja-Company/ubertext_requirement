====================
Stock Report
====================

Installation
============
`Install <https://blog.miftahussalam.com/install-apps-odoo/>`__ this module in a usual way

Configuration
=============


Usage
=====
* Go to ``Inventory >> Reporting >> Stock Report``

Uninstallation
==============
Uninstall this module in a usual way